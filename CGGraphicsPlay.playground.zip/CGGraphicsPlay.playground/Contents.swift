import UIKit

class ViewController:UIViewController{
    var imageView1 = UIImageView()
    var imageView2 = UIImageView()
    
    func drawStuff(){
        let bounds = imageView2.bounds
        let renderer = UIGraphicsImageRenderer(size: bounds.size)
        let image = renderer.image { rendered in
            let context = rendered.cgContext
            context.move(to: CGPoint(x:bounds.midX, y:bounds.midY))
            context.addLine(to: CGPoint(x: 100, y: 100))
            context.addLine(dx: 0, dy: 100)
            context.addLine(dx: 100, dy: 0)
            context.addLine(distance: 30, degrees: 30)
            context.setStrokeColor(UIColor.black.cgColor)
            context.setLineWidth(5)
            context.setLineCap(.round)
            context.setLineJoin(.round)
            context.strokePath()
            
        }
        imageView2.image = image
    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        imageView1.frame = view.bounds
        imageView1.backgroundColor = .blue
        view.addSubview(imageView1)
        //imageView2.frame = CGRect(origin: CGPoint(x: view.bounds.midX, y: view.bounds.midY), size: CGSize(width: 150, height: 100))
        imageView2.frame = imageView1.bounds.insetBy(dx: 20, dy: 20)
        imageView2.backgroundColor = .green
        view.addSubview(imageView2)
        drawStuff()
    }
    
    override func loadView(){
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
     
        view.backgroundColor = .systemBackground
        self.view = view
    }
}

extension CGContext{
    func addLine(dx:CGFloat,dy:CGFloat){
        var point = self.currentPointOfPath
        point.x += dx
        point.y += dy
        self.addLine(to:point)
    }
    
    func addLine(distance:CGFloat,heading:CGFloat){
        var point = self.currentPointOfPath
        point.x += distance * cos(heading)
        point.y += distance * sin(heading)
        self.addLine(to:point)
    }
    
    func addLine(distance:CGFloat,degrees:CGFloat){
        let heading = degrees * (CGFloat.pi / 180)
        self.addLine(distance: distance, heading: heading)
    }
}


import PlaygroundSupport
let vc = ViewController()
PlaygroundPage.current.setLiveView(vc)
